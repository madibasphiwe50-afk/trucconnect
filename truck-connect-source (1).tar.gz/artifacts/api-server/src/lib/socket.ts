import { Server as SocketIOServer } from "socket.io";
import { type Server as HttpServer } from "http";
import { logger } from "./logger";
import { db, driversTable } from "@workspace/db";
import { eq } from "drizzle-orm";

export function initSocketIO(httpServer: HttpServer): SocketIOServer {
  const io = new SocketIOServer(httpServer, {
    path: "/api/socket.io",
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
  });

  io.on("connection", (socket) => {
    logger.info({ socketId: socket.id }, "Socket client connected");

    socket.on(
      "driver:location",
      async (data: { driverId: number; lat: number; lng: number }) => {
        const { driverId, lat, lng } = data;
        try {
          await db
            .update(driversTable)
            .set({ lastLat: lat, lastLng: lng })
            .where(eq(driversTable.id, driverId));
        } catch (err) {
          logger.error({ err }, "Failed to update driver location");
        }
        socket.broadcast.emit("driver:location", { driverId, lat, lng });
      }
    );

    socket.on(
      "driver:status",
      (data: { driverId: number; isOnline: boolean }) => {
        socket.broadcast.emit("driver:status", data);
      }
    );

    socket.on(
      "trip:update",
      (data: { tripId: number; status: string; driverId?: number }) => {
        io.emit("trip:update", data);
      }
    );

    socket.on("disconnect", () => {
      logger.info({ socketId: socket.id }, "Socket client disconnected");
    });
  });

  return io;
}
