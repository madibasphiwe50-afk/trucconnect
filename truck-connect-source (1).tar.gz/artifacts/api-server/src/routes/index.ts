import { Router, type IRouter } from "express";
import healthRouter from "./health";
import tripsRouter from "./trips";
import driversRouter from "./drivers";

const router: IRouter = Router();

router.use(healthRouter);
router.use(tripsRouter);
router.use(driversRouter);

export default router;
