import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, driversTable } from "@workspace/db";
import {
  CreateDriverBody,
  UpdateDriverStatusBody,
  UpdateDriverStatusParams,
  GetDriverParams,
  ListDriversResponse,
  GetDriverResponse,
  GetOnlineDriversResponse,
  UpdateDriverStatusResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function serializeDates<T extends Record<string, unknown>>(obj: T): T {
  return Object.fromEntries(
    Object.entries(obj).map(([k, v]) => [k, v instanceof Date ? v.toISOString() : v])
  ) as T;
}

router.get("/drivers", async (req, res): Promise<void> => {
  const drivers = await db
    .select()
    .from(driversTable)
    .orderBy(desc(driversTable.createdAt));
  res.json(ListDriversResponse.parse(drivers.map(serializeDates)));
});

router.post("/drivers", async (req, res): Promise<void> => {
  const parsed = CreateDriverBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [driver] = await db
    .insert(driversTable)
    .values(parsed.data)
    .returning();
  res.status(201).json(GetDriverResponse.parse(serializeDates(driver)));
});

router.get("/drivers/online", async (req, res): Promise<void> => {
  const drivers = await db
    .select()
    .from(driversTable)
    .where(eq(driversTable.isOnline, true));
  res.json(GetOnlineDriversResponse.parse(drivers.map(serializeDates)));
});

router.get("/drivers/:id", async (req, res): Promise<void> => {
  const params = GetDriverParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [driver] = await db
    .select()
    .from(driversTable)
    .where(eq(driversTable.id, params.data.id));
  if (!driver) {
    res.status(404).json({ error: "Driver not found" });
    return;
  }
  res.json(GetDriverResponse.parse(serializeDates(driver)));
});

router.patch("/drivers/:id/status", async (req, res): Promise<void> => {
  const params = UpdateDriverStatusParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateDriverStatusBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [driver] = await db
    .update(driversTable)
    .set({
      isOnline: parsed.data.isOnline,
      ...(parsed.data.lastLat !== undefined
        ? { lastLat: parsed.data.lastLat }
        : {}),
      ...(parsed.data.lastLng !== undefined
        ? { lastLng: parsed.data.lastLng }
        : {}),
    })
    .where(eq(driversTable.id, params.data.id))
    .returning();
  if (!driver) {
    res.status(404).json({ error: "Driver not found" });
    return;
  }
  res.json(UpdateDriverStatusResponse.parse(serializeDates(driver)));
});

export default router;
