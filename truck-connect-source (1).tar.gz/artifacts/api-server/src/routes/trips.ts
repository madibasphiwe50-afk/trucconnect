import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, tripsTable } from "@workspace/db";
import {
  CreateTripBody,
  UpdateTripStatusBody,
  UpdateTripStatusParams,
  GetTripParams,
  ListTripsResponse,
  GetTripResponse,
  GetActiveTripsResponse,
  GetTripStatsResponse,
  UpdateTripStatusResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function serializeDates<T extends Record<string, unknown>>(obj: T): T {
  return Object.fromEntries(
    Object.entries(obj).map(([k, v]) => [k, v instanceof Date ? v.toISOString() : v])
  ) as T;
}

router.get("/trips", async (req, res): Promise<void> => {
  const trips = await db
    .select()
    .from(tripsTable)
    .orderBy(desc(tripsTable.createdAt));
  res.json(ListTripsResponse.parse(trips.map(serializeDates)));
});

router.post("/trips", async (req, res): Promise<void> => {
  const parsed = CreateTripBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [trip] = await db.insert(tripsTable).values(parsed.data).returning();
  res.status(201).json(GetTripResponse.parse(serializeDates(trip)));
});

router.get("/trips/active", async (req, res): Promise<void> => {
  const trips = await db
    .select()
    .from(tripsTable)
    .where(eq(tripsTable.status, "requested"))
    .orderBy(desc(tripsTable.updatedAt));
  res.json(GetActiveTripsResponse.parse(trips.map(serializeDates)));
});

router.get("/trips/stats", async (req, res): Promise<void> => {
  const all = await db.select().from(tripsTable);
  const driversResult = await db.query.driversTable.findMany({
    where: (d, { eq: eqFn }) => eqFn(d.isOnline, true),
  });
  const stats = {
    total: all.length,
    active: all.filter((t) =>
      ["accepted", "pickup", "active"].includes(t.status)
    ).length,
    completed: all.filter((t) => t.status === "completed").length,
    cancelled: all.filter((t) => t.status === "cancelled").length,
    onlineDrivers: driversResult.length,
  };
  res.json(GetTripStatsResponse.parse(stats));
});

router.get("/trips/:id", async (req, res): Promise<void> => {
  const params = GetTripParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [trip] = await db
    .select()
    .from(tripsTable)
    .where(eq(tripsTable.id, params.data.id));
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }
  res.json(GetTripResponse.parse(serializeDates(trip)));
});

router.patch("/trips/:id/status", async (req, res): Promise<void> => {
  const params = UpdateTripStatusParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateTripStatusBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [trip] = await db
    .update(tripsTable)
    .set({
      status: parsed.data.status,
      ...(parsed.data.driverId !== undefined
        ? { driverId: parsed.data.driverId }
        : {}),
      ...(parsed.data.estimatedMinutes !== undefined
        ? { estimatedMinutes: parsed.data.estimatedMinutes }
        : {}),
      ...(parsed.data.distanceKm !== undefined
        ? { distanceKm: parsed.data.distanceKm }
        : {}),
    })
    .where(eq(tripsTable.id, params.data.id))
    .returning();
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }
  res.json(UpdateTripStatusResponse.parse(serializeDates(trip)));
});

export default router;
