import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import Map from "@/components/map";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ModeToggle } from "@/components/mode-toggle";
import {
  ArrowLeft,
  Search,
  MapPin,
  Clock,
  Truck,
  Navigation,
  CheckCircle2,
} from "lucide-react";
import {
  useCreateTrip,
  useGetActiveTrips,
  getGetActiveTripsQueryKey,
  useGetOnlineDrivers,
  getGetOnlineDriversQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getSocket } from "@/lib/socket";

const JOHANNESBURG: [number, number] = [28.0473, -26.2041];

const SAMPLE_DESTINATIONS = [
  {
    label: "OR Tambo International Airport",
    address: "OR Tambo International Airport",
    lat: -26.1337,
    lng: 28.2421,
  },
  {
    label: "Sandton City Mall",
    address: "Sandton City, Sandhurst",
    lat: -26.1076,
    lng: 28.0567,
  },
  {
    label: "Soweto, Orlando West",
    address: "Soweto, Orlando West",
    lat: -26.2485,
    lng: 27.8548,
  },
  {
    label: "Fourways Mall",
    address: "Fourways Mall",
    lat: -26.0278,
    lng: 28.0101,
  },
  {
    label: "Rosebank Mall",
    address: "Rosebank Mall",
    lat: -26.1469,
    lng: 28.043,
  },
];

export default function CustomerView() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [myPosition] = useState<[number, number]>(JOHANNESBURG);
  const [driverPosition, setDriverPosition] = useState<[number, number] | null>(null);
  const [tripState, setTripState] = useState<
    "idle" | "searching" | "requested" | "accepted" | "pickup" | "active" | "completed"
  >("idle");
  const [currentTripId, setCurrentTripId] = useState<number | null>(null);
  const [selectedDest, setSelectedDest] = useState<{
    label: string;
    address: string;
    lat: number;
    lng: number;
  } | null>(null);
  const [eta, setEta] = useState<number | null>(null);
  const socket = getSocket();

  const createTrip = useCreateTrip();
  const { data: activeTrips } = useGetActiveTrips({
    query: {
      queryKey: getGetActiveTripsQueryKey(),
      refetchInterval: 5000,
    },
  });
  const { data: onlineDrivers } = useGetOnlineDrivers({
    query: {
      queryKey: getGetOnlineDriversQueryKey(),
      refetchInterval: 8000,
    },
  });

  // Listen for real-time updates
  useEffect(() => {
    socket.on("driver:location", (data: { driverId: number; lat: number; lng: number }) => {
      setDriverPosition([data.lng, data.lat]);
    });

    socket.on("trip:update", (data: { tripId: number; status: string }) => {
      if (data.tripId === currentTripId) {
        setTripState(data.status as typeof tripState);
        if (data.status === "accepted") setEta(Math.floor(Math.random() * 10) + 5);
        if (data.status === "pickup") setEta(Math.floor(Math.random() * 20) + 10);
        if (data.status === "completed") {
          setTimeout(() => {
            setTripState("completed");
          }, 500);
        }
      }
    });

    return () => {
      socket.off("driver:location");
      socket.off("trip:update");
    };
  }, [socket, currentTripId]);

  const filteredDestinations = SAMPLE_DESTINATIONS.filter((d) =>
    d.label.toLowerCase().includes(search.toLowerCase())
  );

  const handleRequestTrip = async () => {
    if (!selectedDest) return;
    setTripState("searching");

    try {
      const trip = await createTrip.mutateAsync({
        data: {
          customerName: "You",
          pickupAddress: "Your current location, Johannesburg",
          pickupLat: myPosition[1],
          pickupLng: myPosition[0],
          destinationAddress: selectedDest.address,
          destinationLat: selectedDest.lat,
          destinationLng: selectedDest.lng,
        },
      });
      setCurrentTripId(trip.id);
      setTripState("requested");
      queryClient.invalidateQueries({ queryKey: getGetActiveTripsQueryKey() });

      // Simulate auto-acceptance after 3s for demo
      setTimeout(() => {
        setTripState("accepted");
        setEta(Math.floor(Math.random() * 10) + 5);
        socket.emit("trip:update", { tripId: trip.id, status: "accepted", driverId: 1 });
      }, 3000);
    } catch {
      setTripState("idle");
    }
  };

  const handleCancelTrip = () => {
    setTripState("idle");
    setCurrentTripId(null);
    setSelectedDest(null);
    setSearch("");
    setDriverPosition(null);
    setEta(null);
  };

  const markers = [
    { id: "you", lng: myPosition[0], lat: myPosition[1], type: "pickup" as const, color: "#3b82f6" },
    ...(selectedDest
      ? [{ id: "dest", lng: selectedDest.lng, lat: selectedDest.lat, type: "destination" as const, color: "#ef4444" }]
      : []),
    ...(driverPosition
      ? [{ id: "driver", lng: driverPosition[0], lat: driverPosition[1], type: "driver" as const }]
      : onlineDrivers?.slice(0, 2).map((d) => ({
          id: `d-${d.id}`,
          lng: d.lastLng ?? JOHANNESBURG[0] + (Math.random() - 0.5) * 0.05,
          lat: d.lastLat ?? JOHANNESBURG[1] + (Math.random() - 0.5) * 0.05,
          type: "driver" as const,
        })) ?? []),
  ];

  const tripStatusLabel = {
    idle: "",
    searching: "Finding you a driver...",
    requested: "Waiting for driver to accept...",
    accepted: "Driver on the way",
    pickup: "Driver arrived — boarding",
    active: "Trip in progress",
    completed: "Trip completed",
  }[tripState];

  const tripStatusColor = {
    idle: "outline",
    searching: "secondary",
    requested: "outline",
    accepted: "default",
    pickup: "default",
    active: "default",
    completed: "default",
  }[tripState] as "outline" | "secondary" | "default";

  return (
    <div className="relative w-full h-screen overflow-hidden bg-background">
      {/* Map */}
      <div className="absolute inset-0">
        <Map center={driverPosition ?? myPosition} zoom={13} markers={markers} />
      </div>

      {/* Top bar */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
        <Link href="/">
          <Button variant="secondary" size="icon" className="shadow-lg backdrop-blur-sm">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          {onlineDrivers && onlineDrivers.length > 0 && (
            <Badge variant="secondary" className="shadow-lg">
              <Truck className="h-3 w-3 mr-1" />
              {onlineDrivers.length} driver{onlineDrivers.length > 1 ? "s" : ""} nearby
            </Badge>
          )}
          <ModeToggle />
        </div>
      </div>

      {/* Bottom panel */}
      <div className="absolute bottom-0 left-0 right-0 z-10 p-4 space-y-3">
        {/* Active trip status */}
        {tripState !== "idle" && (
          <Card className="shadow-2xl backdrop-blur-md bg-card/95">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {tripState === "completed" ? (
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                  ) : (
                    <Navigation className="h-4 w-4 text-primary animate-pulse" />
                  )}
                  <span className="font-semibold text-sm">{tripStatusLabel}</span>
                </div>
                <Badge variant={tripStatusColor}>{tripState}</Badge>
              </div>

              {selectedDest && (
                <div className="text-sm text-muted-foreground space-y-1">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
                    <span>Your location, Johannesburg</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0" />
                    <span className="truncate">{selectedDest.address}</span>
                  </div>
                </div>
              )}

              {eta && tripState !== "idle" && tripState !== "completed" && (
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="font-medium">{eta} min ETA</span>
                </div>
              )}

              {tripState !== "completed" && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={handleCancelTrip}
                >
                  Cancel Trip
                </Button>
              )}
              {tripState === "completed" && (
                <Button className="w-full" onClick={handleCancelTrip}>
                  Book Another Trip
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* Destination search */}
        {tripState === "idle" && (
          <Card className="shadow-2xl backdrop-blur-md bg-card/95">
            <CardContent className="p-4 space-y-3">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Where to?
              </p>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  className="pl-9"
                  placeholder="Search destination..."
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value);
                    setShowSuggestions(true);
                  }}
                  onFocus={() => setShowSuggestions(true)}
                />
              </div>

              {showSuggestions && (
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {filteredDestinations.map((dest) => (
                    <button
                      key={dest.label}
                      className="w-full text-left px-3 py-2.5 rounded-md hover:bg-muted transition-colors flex items-center gap-2.5 text-sm"
                      onClick={() => {
                        setSelectedDest(dest);
                        setSearch(dest.label);
                        setShowSuggestions(false);
                      }}
                    >
                      <MapPin className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <span>{dest.label}</span>
                    </button>
                  ))}
                </div>
              )}

              {selectedDest && (
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">To: {selectedDest.label}</span>
                  </div>
                  <Button
                    className="w-full"
                    onClick={handleRequestTrip}
                    disabled={createTrip.isPending}
                  >
                    {createTrip.isPending ? "Requesting..." : "Request Truck Connect"}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
