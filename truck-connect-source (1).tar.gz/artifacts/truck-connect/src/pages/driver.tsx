import { useState, useEffect, useCallback, useRef } from "react";
import { Link } from "wouter";
import Map from "@/components/map";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ModeToggle } from "@/components/mode-toggle";
import {
  ArrowLeft,
  Navigation,
  MapPin,
  Clock,
  CheckCircle2,
  Power,
  PowerOff,
  Truck,
  Route,
} from "lucide-react";
import {
  useGetActiveTrips,
  getGetActiveTripsQueryKey,
  useUpdateTripStatus,
  useUpdateDriverStatus,
  useListDrivers,
  getListDriversQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getSocket } from "@/lib/socket";

const JOHANNESBURG: [number, number] = [28.0473, -26.2041];
const DEMO_DRIVER_ID = 1;

async function fetchRoute(
  from: [number, number],
  to: [number, number]
): Promise<GeoJSON.FeatureCollection | null> {
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${from[0]},${from[1]};${to[0]},${to[1]}?overview=full&geometries=geojson`;
    const res = await fetch(url);
    const data = await res.json();
    if (data.routes && data.routes[0]) {
      return {
        type: "FeatureCollection",
        features: [
          {
            type: "Feature",
            geometry: data.routes[0].geometry,
            properties: {},
          },
        ],
      };
    }
    return null;
  } catch {
    return null;
  }
}

export default function DriverView() {
  const queryClient = useQueryClient();
  const [isOnline, setIsOnline] = useState(false);
  const [position, setPosition] = useState<[number, number]>(JOHANNESBURG);
  const [heading, setHeading] = useState(0);
  const [activeRoute, setActiveRoute] = useState<GeoJSON.FeatureCollection | null>(null);
  const [activeTrip, setActiveTrip] = useState<{
    id: number;
    customerName: string;
    pickupAddress: string;
    pickupLat: number;
    pickupLng: number;
    destinationAddress: string;
    destinationLat: number;
    destinationLng: number;
    status: string;
    estimatedMinutes: number | null;
    distanceKm: number | null;
  } | null>(null);
  const [driverStatus, setDriverStatus] = useState<"idle" | "heading_to_pickup" | "heading_to_destination">("idle");
  const simulationRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const routeCoords = useRef<[number, number][]>([]);
  const routeIndex = useRef(0);

  const { data: trips } = useGetActiveTrips({
    query: { queryKey: getGetActiveTripsQueryKey() },
  });

  const { data: drivers } = useListDrivers({
    query: { queryKey: getListDriversQueryKey() },
  });

  const updateTripStatus = useUpdateTripStatus();
  const updateDriverStatus = useUpdateDriverStatus();

  const socket = getSocket();

  // Broadcast location via socket
  const broadcastLocation = useCallback(
    (lat: number, lng: number) => {
      socket.emit("driver:location", { driverId: DEMO_DRIVER_ID, lat, lng });
    },
    [socket]
  );

  // GPS tracking
  useEffect(() => {
    if (!isOnline) return;
    if (!navigator.geolocation) return;
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setPosition([longitude, latitude]);
        broadcastLocation(latitude, longitude);
      },
      () => {},
      { enableHighAccuracy: true, maximumAge: 3000 }
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, [isOnline, broadcastLocation]);

  // Simulate movement along route
  const startSimulation = useCallback((coords: [number, number][]) => {
    if (simulationRef.current) clearInterval(simulationRef.current);
    routeCoords.current = coords;
    routeIndex.current = 0;

    simulationRef.current = setInterval(() => {
      if (routeIndex.current >= routeCoords.current.length - 1) {
        if (simulationRef.current) clearInterval(simulationRef.current);
        return;
      }
      const curr = routeCoords.current[routeIndex.current];
      const next = routeCoords.current[Math.min(routeIndex.current + 3, routeCoords.current.length - 1)];
      const dx = next[0] - curr[0];
      const dy = next[1] - curr[1];
      const angle = (Math.atan2(dx, dy) * 180) / Math.PI;
      setHeading(angle);
      setPosition(curr);
      broadcastLocation(curr[1], curr[0]);
      routeIndex.current = Math.min(routeIndex.current + 3, routeCoords.current.length - 1);
    }, 800);
  }, [broadcastLocation]);

  useEffect(() => {
    return () => {
      if (simulationRef.current) clearInterval(simulationRef.current);
    };
  }, []);

  const handleGoOnline = async () => {
    setIsOnline(true);
    socket.emit("driver:status", { driverId: DEMO_DRIVER_ID, isOnline: true });
    await updateDriverStatus.mutateAsync({
      id: DEMO_DRIVER_ID,
      data: { isOnline: true, lastLat: position[1], lastLng: position[0] },
    });
    queryClient.invalidateQueries({ queryKey: getListDriversQueryKey() });
  };

  const handleGoOffline = async () => {
    setIsOnline(false);
    setActiveTrip(null);
    setActiveRoute(null);
    setDriverStatus("idle");
    socket.emit("driver:status", { driverId: DEMO_DRIVER_ID, isOnline: false });
    await updateDriverStatus.mutateAsync({
      id: DEMO_DRIVER_ID,
      data: { isOnline: false },
    });
    queryClient.invalidateQueries({ queryKey: getListDriversQueryKey() });
  };

  const handleAcceptTrip = async (trip: typeof activeTrip) => {
    if (!trip) return;
    setActiveTrip({ ...trip, status: "accepted" });
    setDriverStatus("heading_to_pickup");
    await updateTripStatus.mutateAsync({
      id: trip.id,
      data: { status: "accepted", driverId: DEMO_DRIVER_ID },
    });
    socket.emit("trip:update", { tripId: trip.id, status: "accepted", driverId: DEMO_DRIVER_ID });
    queryClient.invalidateQueries({ queryKey: getGetActiveTripsQueryKey() });

    const route = await fetchRoute(position, [trip.pickupLng, trip.pickupLat]);
    if (route) {
      setActiveRoute(route);
      const coords = (route.features[0].geometry as GeoJSON.LineString).coordinates as [number, number][];
      startSimulation(coords);
    }
  };

  const handleArrivedAtPickup = async () => {
    if (!activeTrip) return;
    setDriverStatus("heading_to_destination");
    setActiveTrip({ ...activeTrip, status: "pickup" });
    await updateTripStatus.mutateAsync({
      id: activeTrip.id,
      data: { status: "pickup" },
    });
    socket.emit("trip:update", { tripId: activeTrip.id, status: "pickup" });

    const route = await fetchRoute(
      [activeTrip.pickupLng, activeTrip.pickupLat],
      [activeTrip.destinationLng, activeTrip.destinationLat]
    );
    if (route) {
      setActiveRoute(route);
      const coords = (route.features[0].geometry as GeoJSON.LineString).coordinates as [number, number][];
      startSimulation(coords);
    }
  };

  const handleStartTrip = async () => {
    if (!activeTrip) return;
    setActiveTrip({ ...activeTrip, status: "active" });
    await updateTripStatus.mutateAsync({
      id: activeTrip.id,
      data: { status: "active" },
    });
    socket.emit("trip:update", { tripId: activeTrip.id, status: "active" });
  };

  const handleEndTrip = async () => {
    if (!activeTrip) return;
    await updateTripStatus.mutateAsync({
      id: activeTrip.id,
      data: { status: "completed" },
    });
    socket.emit("trip:update", { tripId: activeTrip.id, status: "completed" });
    queryClient.invalidateQueries({ queryKey: getGetActiveTripsQueryKey() });
    setActiveTrip(null);
    setActiveRoute(null);
    setDriverStatus("idle");
    if (simulationRef.current) clearInterval(simulationRef.current);
  };

  const pendingTrips = trips?.filter((t) => t.status === "requested") ?? [];
  const currentDriver = drivers?.find((d) => d.id === DEMO_DRIVER_ID);

  const markers = [
    { id: "driver", lng: position[0], lat: position[1], type: "driver" as const, heading },
    ...(activeTrip && driverStatus === "heading_to_pickup"
      ? [{ id: "pickup", lng: activeTrip.pickupLng, lat: activeTrip.pickupLat, type: "pickup" as const, color: "#22c55e" }]
      : []),
    ...(activeTrip && driverStatus === "heading_to_destination"
      ? [{ id: "dest", lng: activeTrip.destinationLng, lat: activeTrip.destinationLat, type: "destination" as const, color: "#ef4444" }]
      : []),
  ];

  return (
    <div className="relative w-full h-screen overflow-hidden bg-background">
      {/* Map */}
      <div className="absolute inset-0">
        <Map center={position} zoom={15} markers={markers} route={activeRoute} />
      </div>

      {/* Top bar */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
        <Link href="/">
          <Button variant="secondary" size="icon" className="shadow-lg backdrop-blur-sm">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Badge
            className="shadow-lg text-sm px-3 py-1"
            variant={isOnline ? "default" : "secondary"}
          >
            <Truck className="h-3 w-3 mr-1" />
            {isOnline ? "Online" : "Offline"}
          </Badge>
          <ModeToggle />
        </div>
      </div>

      {/* Bottom panel */}
      <div className="absolute bottom-0 left-0 right-0 z-10 p-4 space-y-3">
        {/* Active trip info */}
        {activeTrip && (
          <Card className="shadow-2xl backdrop-blur-md bg-card/95">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Navigation className="h-4 w-4 text-primary" />
                  <span className="font-semibold text-sm">
                    {driverStatus === "heading_to_pickup"
                      ? "Heading to pickup"
                      : driverStatus === "heading_to_destination"
                      ? "Trip in progress"
                      : "Trip active"}
                  </span>
                </div>
                <Badge variant="outline">{activeTrip.customerName}</Badge>
              </div>

              <div className="space-y-1 text-sm text-muted-foreground">
                {driverStatus === "heading_to_pickup" && (
                  <div className="flex items-center gap-2">
                    <MapPin className="h-3.5 w-3.5 text-green-500 flex-shrink-0" />
                    <span className="truncate">{activeTrip.pickupAddress}</span>
                  </div>
                )}
                {driverStatus === "heading_to_destination" && (
                  <div className="flex items-center gap-2">
                    <MapPin className="h-3.5 w-3.5 text-red-500 flex-shrink-0" />
                    <span className="truncate">{activeTrip.destinationAddress}</span>
                  </div>
                )}
                {activeTrip.estimatedMinutes && (
                  <div className="flex items-center gap-2">
                    <Clock className="h-3.5 w-3.5 flex-shrink-0" />
                    <span>{activeTrip.estimatedMinutes} min estimated</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                {driverStatus === "heading_to_pickup" && activeTrip.status === "accepted" && (
                  <Button className="flex-1" onClick={handleArrivedAtPickup} size="sm">
                    Arrived at Pickup
                  </Button>
                )}
                {driverStatus === "heading_to_destination" && activeTrip.status === "pickup" && (
                  <Button className="flex-1" onClick={handleStartTrip} size="sm">
                    Start Trip
                  </Button>
                )}
                {activeTrip.status === "active" && (
                  <Button className="flex-1" onClick={handleEndTrip} size="sm" variant="destructive">
                    End Trip
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Pending trip requests */}
        {isOnline && !activeTrip && pendingTrips.length > 0 && (
          <Card className="shadow-2xl backdrop-blur-md bg-card/95">
            <CardContent className="p-4">
              <p className="text-xs font-medium text-muted-foreground mb-3 uppercase tracking-wide">
                Trip Request
              </p>
              {pendingTrips.slice(0, 1).map((trip) => (
                <div key={trip.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{trip.customerName}</span>
                    {trip.distanceKm && (
                      <span className="text-sm text-muted-foreground">{trip.distanceKm.toFixed(1)} km</span>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full bg-green-500 flex-shrink-0" />
                      <span className="truncate">{trip.pickupAddress}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0" />
                      <span className="truncate">{trip.destinationAddress}</span>
                    </div>
                  </div>
                  <Button
                    className="w-full mt-2"
                    onClick={() =>
                      handleAcceptTrip({
                        id: trip.id,
                        customerName: trip.customerName,
                        pickupAddress: trip.pickupAddress,
                        pickupLat: trip.pickupLat,
                        pickupLng: trip.pickupLng,
                        destinationAddress: trip.destinationAddress,
                        destinationLat: trip.destinationLat,
                        destinationLng: trip.destinationLng,
                        status: trip.status,
                        estimatedMinutes: trip.estimatedMinutes ?? null,
                        distanceKm: trip.distanceKm ?? null,
                      })
                    }
                  >
                    Accept Trip
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Online/Offline toggle */}
        {!activeTrip && (
          <Card className="shadow-2xl backdrop-blur-md bg-card/95">
            <CardContent className="p-4">
              {isOnline ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      {pendingTrips.length > 0
                        ? `${pendingTrips.length} trip request${pendingTrips.length > 1 ? "s" : ""} available`
                        : "Waiting for trip requests..."}
                    </span>
                    {currentDriver && (
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5 text-green-500" />
                        <span className="font-medium">{currentDriver.rating.toFixed(1)}</span>
                      </div>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={handleGoOffline}
                    size="sm"
                  >
                    <PowerOff className="h-4 w-4 mr-2" />
                    Go Offline
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground text-center">
                    You are currently offline
                  </p>
                  <Button className="w-full" onClick={handleGoOnline}>
                    <Power className="h-4 w-4 mr-2" />
                    Go Online
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Current position info */}
        {isOnline && (
          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <Route className="h-3 w-3" />
            <span>GPS Active — Johannesburg, South Africa</span>
          </div>
        )}
      </div>
    </div>
  );
}
