import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Truck, User, LayoutDashboard } from "lucide-react";
import { ModeToggle } from "@/components/mode-toggle";

export default function ModeSelector() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center p-4 bg-background relative overflow-hidden">
      <div className="absolute top-4 right-4 z-10">
        <ModeToggle />
      </div>

      {/* Decorative background elements */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none mix-blend-multiply dark:mix-blend-screen" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none mix-blend-multiply dark:mix-blend-screen" />

      <div className="w-full max-w-4xl grid gap-8 md:grid-cols-2 relative z-10">
        <div className="col-span-full text-center space-y-4 mb-8">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
            Truck Connect Maps
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Premium navigation platform built for drivers and customers in Africa.
          </p>
        </div>

        <Card className="hover-elevate transition-all duration-300 border-2 hover:border-primary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Truck className="h-8 w-8 text-primary" />
              Driver Console
            </CardTitle>
            <CardDescription className="text-lg">
              Navigate routes, receive trip requests, and manage your online status.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/driver" className="w-full">
              <Button className="w-full text-lg h-14" size="lg">
                Enter Driver View
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300 border-2 hover:border-primary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <User className="h-8 w-8 text-primary" />
              Customer View
            </CardTitle>
            <CardDescription className="text-lg">
              Request trips, track your driver in real-time, and view ETA.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/customer" className="w-full">
              <Button className="w-full text-lg h-14" variant="secondary" size="lg">
                Enter Customer View
              </Button>
            </Link>
          </CardContent>
        </Card>

        <div className="col-span-full flex justify-center mt-8">
          <Link href="/dashboard">
            <Button variant="outline" className="gap-2" size="lg">
              <LayoutDashboard className="h-5 w-5" />
              System Dashboard
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
