export async function fetchRoute(start: [number, number], end: [number, number]) {
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${start[0]},${start[1]};${end[0]},${end[1]}?overview=full&geometries=geojson`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`OSRM routing failed: ${res.statusText}`);
    }
    const data = await res.json();
    
    if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
       throw new Error('No route found');
    }

    const route = data.routes[0];
    
    const geojson: GeoJSON.FeatureCollection = {
      type: "FeatureCollection",
      features: [
        {
          type: "Feature",
          properties: {},
          geometry: route.geometry
        }
      ]
    };

    return {
      geojson,
      distanceKm: route.distance / 1000,
      durationMinutes: Math.round(route.duration / 60)
    };
  } catch (error) {
    console.error("Error fetching route:", error);
    return null;
  }
}
