import { useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { useTheme } from "@/components/theme-provider";
import { MapPin, Navigation } from "lucide-react";

interface MapProps {
  center: [number, number]; // [lng, lat]
  zoom?: number;
  markers?: Array<{
    id: string;
    lng: number;
    lat: number;
    color?: string;
    heading?: number;
    type?: "driver" | "destination" | "pickup";
  }>;
  route?: GeoJSON.FeatureCollection | null;
  className?: string;
  onMapLoad?: (map: maplibregl.Map) => void;
}

const LIGHT_STYLE = "https://basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png";
const DARK_STYLE = "https://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png";

function MapFallback({
  markers = [],
  isDark,
}: {
  markers: MapProps["markers"];
  isDark: boolean;
}) {
  const driverMarkers = markers?.filter((m) => m.type === "driver") ?? [];
  const pickupMarkers = markers?.filter((m) => m.type === "pickup") ?? [];
  const destMarkers = markers?.filter((m) => m.type === "destination") ?? [];

  return (
    <div
      className="w-full h-full flex flex-col items-center justify-center gap-4 relative overflow-hidden"
      style={{ background: isDark ? "#0a1628" : "#e8edf2" }}
    >
      {/* Grid background to simulate a map */}
      <svg
        className="absolute inset-0 w-full h-full opacity-20"
        style={{ pointerEvents: "none" }}
      >
        <defs>
          <pattern
            id="grid"
            width="40"
            height="40"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 40 0 L 0 0 0 40"
              fill="none"
              stroke={isDark ? "#3b82f6" : "#64748b"}
              strokeWidth="0.5"
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        {/* Simulated road lines */}
        <line
          x1="0"
          y1="50%"
          x2="100%"
          y2="50%"
          stroke={isDark ? "#334155" : "#94a3b8"}
          strokeWidth="6"
        />
        <line
          x1="50%"
          y1="0"
          x2="50%"
          y2="100%"
          stroke={isDark ? "#334155" : "#94a3b8"}
          strokeWidth="6"
        />
        <line
          x1="0"
          y1="30%"
          x2="100%"
          y2="30%"
          stroke={isDark ? "#1e293b" : "#cbd5e1"}
          strokeWidth="3"
        />
        <line
          x1="0"
          y1="70%"
          x2="100%"
          y2="70%"
          stroke={isDark ? "#1e293b" : "#cbd5e1"}
          strokeWidth="3"
        />
        <line
          x1="30%"
          y1="0"
          x2="30%"
          y2="100%"
          stroke={isDark ? "#1e293b" : "#cbd5e1"}
          strokeWidth="3"
        />
        <line
          x1="70%"
          y1="0"
          x2="70%"
          y2="100%"
          stroke={isDark ? "#1e293b" : "#cbd5e1"}
          strokeWidth="3"
        />
      </svg>

      {/* Markers summary */}
      <div className="relative z-10 flex flex-col items-center gap-3 px-6 py-5 rounded-2xl backdrop-blur-sm"
        style={{ background: isDark ? "rgba(10,22,40,0.85)" : "rgba(255,255,255,0.85)" }}
      >
        <div className="flex items-center gap-2">
          <Navigation className="h-5 w-5 text-primary" />
          <span className="font-semibold text-sm" style={{ color: isDark ? "#f1f5f9" : "#0f172a" }}>
            Johannesburg, South Africa
          </span>
        </div>

        {driverMarkers.length > 0 && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="w-3 h-3 rounded-full bg-blue-500" />
            <span>{driverMarkers.length} driver{driverMarkers.length > 1 ? "s" : ""} active</span>
          </div>
        )}
        {pickupMarkers.length > 0 && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span>Pickup point set</span>
          </div>
        )}
        {destMarkers.length > 0 && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <span>Destination set</span>
          </div>
        )}

        <p className="text-xs text-muted-foreground mt-1 text-center max-w-[240px]">
          Map renders fully in a standard browser with WebGL support
        </p>
      </div>
    </div>
  );
}

export default function Map({
  center,
  zoom = 13,
  markers = [],
  route = null,
  className = "",
  onMapLoad,
}: MapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<{ [key: string]: maplibregl.Marker }>({});
  const { theme } = useTheme();
  const [webGLError, setWebGLError] = useState(false);

  const isDark =
    theme === "dark" ||
    (theme === "system" &&
      window.matchMedia("(prefers-color-scheme: dark)").matches);
  const styleUrl = isDark ? DARK_STYLE : LIGHT_STYLE;

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current) return;
    if (mapRef.current) return;

    // Check WebGL support before trying
    const canvas = document.createElement("canvas");
    const gl =
      canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    if (!gl) {
      setWebGLError(true);
      return;
    }

    try {
      const style: maplibregl.StyleSpecification = {
        version: 8,
        sources: {
          carto: {
            type: "raster",
            tiles: [styleUrl],
            tileSize: 256,
          },
        },
        layers: [
          {
            id: "carto",
            type: "raster",
            source: "carto",
            minzoom: 0,
            maxzoom: 22,
          },
        ],
      };

      mapRef.current = new maplibregl.Map({
        container: mapContainer.current,
        style,
        center,
        zoom,
        attributionControl: false,
        failIfMajorPerformanceCaveat: false,
      });

      mapRef.current.addControl(
        new maplibregl.NavigationControl(),
        "top-right"
      );

      mapRef.current.on("load", () => {
        if (!mapRef.current) return;

        mapRef.current.addSource("route", {
          type: "geojson",
          data: { type: "FeatureCollection", features: [] },
        });

        mapRef.current.addLayer({
          id: "route",
          type: "line",
          source: "route",
          layout: { "line-join": "round", "line-cap": "round" },
          paint: {
            "line-color": isDark ? "#ffffff" : "#000000",
            "line-width": 4,
          },
        });

        if (onMapLoad) onMapLoad(mapRef.current);
      });

      mapRef.current.on("error", () => {
        setWebGLError(true);
      });
    } catch {
      setWebGLError(true);
    }

    return () => {
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  // Update style on theme change
  useEffect(() => {
    if (!mapRef.current || !mapRef.current.isStyleLoaded()) return;
    const newStyleUrl = isDark ? DARK_STYLE : LIGHT_STYLE;
    const source = mapRef.current.getSource("carto") as maplibregl.RasterTileSource;
    if (source && typeof (source as unknown as { setTiles: (t: string[]) => void }).setTiles === "function") {
      (source as unknown as { setTiles: (t: string[]) => void }).setTiles([newStyleUrl]);
    }
    if (mapRef.current.getLayer("route")) {
      mapRef.current.setPaintProperty(
        "route",
        "line-color",
        isDark ? "#ffffff" : "#000000"
      );
    }
  }, [isDark]);

  // Update route
  useEffect(() => {
    if (!mapRef.current || !mapRef.current.isStyleLoaded()) return;
    const source = mapRef.current.getSource("route") as maplibregl.GeoJSONSource;
    if (!source) return;

    if (route) {
      source.setData(route);
      const coords =
        route.features[0]?.geometry?.type === "LineString"
          ? (route.features[0].geometry.coordinates as [number, number][])
          : [];
      if (coords.length > 0) {
        const bounds = coords.reduce(
          (b, c) => b.extend(c),
          new maplibregl.LngLatBounds(coords[0], coords[0])
        );
        mapRef.current.fitBounds(bounds, { padding: 50 });
      }
    } else {
      source.setData({ type: "FeatureCollection", features: [] });
    }
  }, [route]);

  // Update markers
  useEffect(() => {
    if (!mapRef.current) return;

    const currentIds = new Set(markers.map((m) => m.id));
    Object.keys(markersRef.current).forEach((id) => {
      if (!currentIds.has(id)) {
        markersRef.current[id].remove();
        delete markersRef.current[id];
      }
    });

    markers.forEach((markerInfo) => {
      if (markersRef.current[markerInfo.id]) {
        markersRef.current[markerInfo.id].setLngLat([markerInfo.lng, markerInfo.lat]);
        if (markerInfo.heading !== undefined) {
          const el = markersRef.current[markerInfo.id].getElement();
          if (el.firstChild) {
            (el.firstChild as HTMLElement).style.transform = `rotate(${markerInfo.heading}deg)`;
          }
        }
      } else {
        const el = document.createElement("div");
        el.className = "custom-marker";

        if (markerInfo.type === "driver") {
          el.innerHTML = `
            <div style="width:24px;height:24px;background:#3b82f6;border-radius:50%;display:flex;align-items:center;justify-content:center;border:2px solid white;box-shadow:0 2px 4px rgba(0,0,0,.3);transform-origin:center;transform:rotate(${markerInfo.heading || 0}deg);transition:transform .3s ease;">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 22l10-4 10 4L12 2z"/></svg>
            </div>`;
        } else {
          el.innerHTML = `<div style="width:16px;height:16px;background:${markerInfo.color || "#ef4444"};border-radius:50%;border:2px solid white;box-shadow:0 2px 4px rgba(0,0,0,.3);"></div>`;
        }

        const marker = new maplibregl.Marker({ element: el })
          .setLngLat([markerInfo.lng, markerInfo.lat])
          .addTo(mapRef.current!);
        markersRef.current[markerInfo.id] = marker;
      }
    });
  }, [markers]);

  // Pan to center
  useEffect(() => {
    if (!mapRef.current || route) return;
    mapRef.current.easeTo({ center, duration: 1000 });
  }, [center[0], center[1]]);

  if (webGLError) {
    return (
      <div className={`relative w-full h-full ${className}`}>
        <MapFallback markers={markers} isDark={isDark} />
      </div>
    );
  }

  return (
    <div className={`relative w-full h-full ${className}`}>
      <div ref={mapContainer} className="absolute inset-0 w-full h-full" />
    </div>
  );
}
