import {
  pgTable,
  text,
  serial,
  timestamp,
  boolean,
  doublePrecision,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const driversTable = pgTable("drivers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  vehicleModel: text("vehicle_model").notNull(),
  vehiclePlate: text("vehicle_plate").notNull(),
  isOnline: boolean("is_online").notNull().default(false),
  lastLat: doublePrecision("last_lat"),
  lastLng: doublePrecision("last_lng"),
  rating: doublePrecision("rating").notNull().default(4.8),
  tripsCompleted: integer("trips_completed").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertDriverSchema = createInsertSchema(driversTable).omit({
  id: true,
  createdAt: true,
});
export type InsertDriver = z.infer<typeof insertDriverSchema>;
export type Driver = typeof driversTable.$inferSelect;
